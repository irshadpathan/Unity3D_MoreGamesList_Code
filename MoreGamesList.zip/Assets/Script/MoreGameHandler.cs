﻿// *********** Developer Irshad Khan : http://www.irshadkhan.info ************** Open source license **************//

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// More game handler.
/// </summary>
public class MoreGameHandler : MonoBehaviour {

	[Tooltip("Here Json Output api Url")]
	public string baseurl;

	[Tooltip("Here Drage for GamePanel")]
	public GameObject Gamepanel;

	[SerializeField][HideInInspector]
	private List<GameObject> GameList;

	[Tooltip("Target for Gamelisting ReactTranform")]
	public Transform targetlist;

	private Root Directory;



	void Start()
	{

		StartCoroutine ("LoadMoreGame");
	}


	// Load Game Listing
	IEnumerator LoadMoreGame()
	{

		WWW url = new WWW (baseurl);

		IDebug.Log ("please Wait.........");

		yield return url;

		if (url.error != null) {
		
			IDebug.LogError ("Please Check Connection");

		} else {
			Directory =	JsonUtility.FromJson<Root> (url.text);

			PoolList (Directory.MyList.Count);


			for (int i = 0; i < Directory.MyList.Count; i++) {
				
				WWW icons = new WWW (Directory.MyList [i].icon);

				yield return icons;

				GameList [i].transform.GetChild (0).GetComponent<RawImage> ().texture = icons.texture;
				GameList [i].transform.GetChild (1).GetComponent<Text> ().text = "Name : " + Directory.MyList [i].Name;
				GameList [i].transform.GetChild (2).GetComponent<Text> ().text = Directory.MyList [i].shortdec;
				GameList [i].transform.GetChild (3).GetComponent<Text> ().text = Directory.MyList [i].downloadcount;
				GameList [i].transform.GetChild (4).GetComponent<Image> ().fillAmount = Directory.MyList [i].reviewstar;

				IDebug.Log ("Enjoy It!!!!!!!!!!!!!!!!!!!!!");

				//Click Event Open Google play store 
				int ik = i;
				GameList [i].transform.GetChild (5).GetComponent<Button> ().onClick.AddListener(() => DownloadAPK(Directory.MyList[ik].downloadurl));

			}
		}

	}


	// Open Google play store 
	private void DownloadAPK(string durl)
	{
		Application.OpenURL (durl);
	}


	// Pooling List For Load Game
	private GameObject PoolList(int index)
	{
		for (int i = 0; i < index; i++) {

			GameObject go =	Instantiate (Gamepanel);

			GameList.Add (go);

			go.transform.parent = targetlist;

		}

		return null;
	}

}


[System.Serializable]
public class Root
{
	public List<BaseRoot> MyList;
}
[System.Serializable]	
public class BaseRoot
{
	public string icon;
	public string Name;
	public string shortdec;
	public string downloadcount;
	public float  reviewstar;
	public string downloadurl;
}











